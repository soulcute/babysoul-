import { getStore } from '@netlify/blobs';
import crypto from 'node:crypto';

const store = getStore('moosap-data');
const defaults = {
  name: 'MOOSAP',
  welcome: 'WELCOME TO MY LITTLE WORLD',
  bio: 'ยินดีต้อนรับเข้าสู่หน้าโปรไฟล์ของเรา',
  avatar: '', cover: '', bg: '',
  links: [
    {name:'LINE',url:'#',show:true},
    {name:'DISCORD',url:'#',show:true},
    {name:'FACEBOOK',url:'#',show:true},
    {name:'INSTAGRAM',url:'#',show:true}
  ]
};

const json = (body, status=200, extra={}) => ({
  statusCode: status,
  headers: {'content-type':'application/json; charset=utf-8', ...extra},
  body: JSON.stringify(body)
});

async function readData(){
  const d = await store.get('site', {type:'json'});
  return d || {settings: defaults, reviews: []};
}
async function writeData(d){ await store.setJSON('site', d); }
function secret(){ return process.env.ADMIN_PASSWORD || 'change-this-password'; }
function sign(value){ return crypto.createHmac('sha256', secret()).update(value).digest('hex'); }
function cookie(name,value,maxAge=60*60*24*7){ return `${name}=${value}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAge}`; }
function isAdmin(event){
  const raw = event.headers.cookie || event.headers.Cookie || '';
  const m = raw.match(/(?:^|;\s*)moosap_admin=([^;]+)/);
  if(!m) return false;
  const [v,sig] = decodeURIComponent(m[1]).split('.');
  return !!v && sig === sign(v);
}
function pathOf(event){ return event.path.replace(/^\/.netlify\/functions\/api/, '').replace(/^\/api/, '') || '/'; }

export default async (event) => {
  try {
    const method = event.httpMethod;
    const path = pathOf(event);
    const body = event.body ? JSON.parse(event.body) : {};

    if(method === 'GET' && path === '/site'){
      const d = await readData();
      d.settings = {...defaults, ...(d.settings||{})};
      return json(d);
    }

    if(method === 'POST' && path === '/admin/login'){
      if(String(body.password||'') !== secret()) return json({error:'รหัสผ่านไม่ถูกต้อง'},401);
      const token = `1.${sign('1')}`;
      return json({ok:true},200,{'set-cookie':cookie('moosap_admin',encodeURIComponent(token))});
    }

    if(method === 'POST' && path === '/admin/logout'){
      return json({ok:true},200,{'set-cookie':cookie('moosap_admin','',0)});
    }

    if(method === 'POST' && path === '/reviews'){
      const d = await readData();
      const text = String(body.text||'').trim();
      if(!text) return json({error:'กรุณาเขียนรีวิว'},400);
      const rating = Math.min(5,Math.max(1,Number(body.rating)||5));
      const review = {
        id: crypto.randomUUID(),
        name: String(body.name||'ลูกค้า').slice(0,80), rating,
        text:text.slice(0,1000), avatar:String(body.avatar||'').slice(0,2000),
        image:String(body.image||'').slice(0,2000), pinned:false, hidden:false,
        date:new Date().toISOString()
      };
      d.reviews = [review, ...(d.reviews||[])];
      await writeData(d);
      return json(review);
    }

    if(path.startsWith('/admin/') && !isAdmin(event)) return json({error:'กรุณาเข้าสู่ระบบแอดมิน'},401);

    if(method === 'POST' && path === '/admin/settings'){
      const d = await readData();
      d.settings = {...defaults, ...(d.settings||{}), ...body};
      await writeData(d);
      return json(d.settings);
    }

    const match = path.match(/^\/admin\/reviews\/([^/]+)$/);
    if(match && method === 'PATCH'){
      const d = await readData();
      const r = (d.reviews||[]).find(x=>x.id===match[1]);
      if(!r) return json({error:'ไม่พบรีวิว'},404);
      Object.assign(r, body); await writeData(d); return json(r);
    }
    if(match && method === 'DELETE'){
      const d = await readData();
      d.reviews = (d.reviews||[]).filter(x=>x.id!==match[1]);
      await writeData(d); return json({ok:true});
    }
    return json({error:'Not found'},404);
  } catch(e){
    console.error(e);
    return json({error:'Server error'},500);
  }
};
