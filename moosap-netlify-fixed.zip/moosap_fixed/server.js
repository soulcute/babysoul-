const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();
const PORT = process.env.PORT || 3000;
const DATA = path.join(__dirname, "data", "site.json");

app.use(express.json({limit:"5mb"}));
app.use(express.urlencoded({extended:true, limit:"5mb"}));
app.use(express.static(path.join(__dirname,"public")));

function readData(){
  if(!fs.existsSync(DATA)) fs.writeFileSync(DATA, JSON.stringify({settings:{},reviews:[]},null,2));
  return JSON.parse(fs.readFileSync(DATA,"utf8"));
}
function writeData(d){ fs.writeFileSync(DATA, JSON.stringify(d,null,2)); }

app.get("/api/site",(req,res)=>res.json(readData()));

app.post("/api/reviews",(req,res)=>{
  const d=readData(), b=req.body;
  const review={
    id: Date.now().toString(),
    name:String(b.name||"ลูกค้า").slice(0,80),
    rating:Math.min(5,Math.max(1,Number(b.rating)||5)),
    text:String(b.text||"").slice(0,1000),
    avatar:String(b.avatar||"").slice(0,200000),
    image:String(b.image||"").slice(0,200000),
    pinned:false, hidden:false,
    date:new Date().toISOString()
  };
  if(!review.text.trim()) return res.status(400).json({error:"กรุณาเขียนรีวิว"});
  d.reviews.unshift(review); writeData(d); res.json(review);
});

app.post("/api/admin/settings",(req,res)=>{
  const d=readData(); d.settings={...d.settings,...req.body}; writeData(d); res.json(d.settings);
});
app.patch("/api/admin/reviews/:id",(req,res)=>{
  const d=readData(), r=d.reviews.find(x=>x.id===req.params.id);
  if(!r) return res.status(404).json({error:"ไม่พบรีวิว"});
  Object.assign(r,req.body); writeData(d); res.json(r);
});
app.delete("/api/admin/reviews/:id",(req,res)=>{
  const d=readData(); d.reviews=d.reviews.filter(x=>x.id!==req.params.id); writeData(d); res.json({ok:true});
});

app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log("http://localhost:"+PORT));
