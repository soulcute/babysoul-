# MOOSAP Profile — Netlify version

เวอร์ชันนี้แก้ให้ใช้กับ Netlify ได้โดยไม่ต้องรัน `server.js` แบบ VPS

## Deploy
1. อัปโหลดโฟลเดอร์นี้ไป GitHub แล้ว Import โปรเจกต์เข้า Netlify หรือใช้ Netlify CLI
2. Build command: เว้นว่าง
3. Publish directory: `public`
4. Functions directory: `netlify/functions`
5. ตั้ง Environment Variable ชื่อ `ADMIN_PASSWORD` เป็นรหัสผ่านหลังบ้านที่ต้องการ
6. Deploy แล้วเข้า `/admin`

ข้อมูลเว็บและรีวิวเก็บใน Netlify Blobs จึงไม่หายเมื่อมีการ deploy ใหม่

## Domain
ใน Netlify ไปที่ Domain management > Add a domain แล้วเพิ่มโดเมนของคุณ จากนั้นทำ DNS ตามค่าที่ Netlify แสดง
